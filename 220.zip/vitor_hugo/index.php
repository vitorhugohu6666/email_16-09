<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bem-vindo</title>
	<!-- CSS Boostrapp -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
	<style>
	
		
		.img-fluid {
			height: 250px;
			width: 300px;
			border-radius: 20px;
			margin-top: 20px;
		}
		
	
	</style>
</head>

<script type="text/javascript"> 
	function rederect() {
			window.location = "login.php"
			//window.location = "manuntencao.php"
	}
 </script>

<body onLoad="setTimeout('rederect()', 2000)" class="bg-primary">
<center>

	<img src="imagens/loja.png" class="img-fluid" alt="Logo Marca" >
	
</center>

<center>

	<div class="spinner-border" role="status">
		<span class="visually-hidden">Carregando...</span>
	</div>
</center>

<center>
	<p class="text-light">Bem-vindo! Sistema carregando...</p>
</center>
</body>
</html>