<?php
session_start();
include("conexao.php");
include("valida_login.php");

$codigoEnviado = $_POST["codigo"];
$pegarCodigo = mysqli_query($conection, "SELECT codigo_acesso FROM usuarios WHERE nome = '$usuario'");
$resultadoCodigo = mysqli_fetch_assoc($pegarCodigo);
$valorCodigo = $resultadoCodigo["codigo_acesso"];

if($codigoEnviado == $valorCodigo) {
    $_SESSION["acesso"] = 'Liberado';
    header("Location: dashboard.php");
} else {
    header("Location: codigo_email.php?codigo=1");
}

?>