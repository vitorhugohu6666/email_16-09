<?php
		session_start();
	
		$usuario = $_POST["nome"];
		$senha = $_POST["senha"]; 
		$senha_segura = password_hash($senha, PASSWORD_DEFAULT);
		
		include("conexao.php");
		$cadastro = mysqli_query($conection, "INSERT INTO usuarios(nome, senha) VALUES ('$usuario', '$senha_segura')");
		header('Location: dashboard.php?isSucess=true');
?>

